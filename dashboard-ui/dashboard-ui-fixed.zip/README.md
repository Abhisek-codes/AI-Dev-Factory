# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Oxc](https://oxc.rs)
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/)

## React Compiler

The React Compiler is not enabled on this template because of its impact on dev & build performances. To add it, see [this documentation](https://react.dev/learn/react-compiler/installation).

## Expanding the ESLint configuration

If you are developing a production application, we recommend using TypeScript with type-aware lint rules enabled. Check out the [TS template](https://github.com/vitejs/vite/tree/main/packages/create-vite/template-react-ts) for information on how to integrate TypeScript and [`typescript-eslint`](https://typescript-eslint.io) in your project.

## Backend For Frontend (BFF)

This project now includes a lightweight BFF server at [server/bff-server.js](server/bff-server.js) that:

- Serves the built React app from `dist/`
- Proxies all `/api/*` requests (including SSE) to the backend API

The browser only calls relative `/api/...` routes. The backend URL is resolved by the BFF at runtime.

### Local development

- `npm run dev` uses Vite with a dev proxy to backend.
- Set `VITE_BACKEND_PROXY_TARGET` if your backend is not `http://localhost:8000`.

### BFF health endpoint

- `GET /bff-health`
- Returns service status and current backend target.

### Production / Azure Web App

1. Build the UI: `npm run build`
2. Start the BFF: `npm start`
3. Configure Azure App Settings:
	- `BACKEND_URL=https://<your-backend-app>.azurewebsites.net`
	- `PORT` is provided by Azure automatically

This keeps backend URLs out of the client bundle and allows backend target changes without rebuilding frontend code.

## Local testing steps

### Option A: Fast local dev (Vite dev server + proxy)

1. Start backend on `http://localhost:8000`.
2. In this folder, install dependencies: `npm install`.
3. Run UI: `npm run dev`.
4. Open the Vite URL (usually `http://localhost:5173`).

If backend runs on another URL, set `VITE_BACKEND_PROXY_TARGET` before starting dev server.

PowerShell example:

```powershell
$env:VITE_BACKEND_PROXY_TARGET = "http://localhost:8000"
npm run dev
```

CMD example:

```cmd
set VITE_BACKEND_PROXY_TARGET=http://localhost:8000
npm run dev
```

### Option B: Production-like local test (BFF server)

1. Start backend.
2. Build UI: `npm run build`.
3. Set required env var `BACKEND_URL`.
4. Start BFF: `npm start`.
5. Open `http://localhost:8080`.
6. Verify BFF: open `http://localhost:8080/bff-health`.

PowerShell example:

```powershell
$env:BACKEND_URL = "http://localhost:8000"
npm run build
npm start
```

CMD example:

```cmd
set BACKEND_URL=http://localhost:8000
npm run build
npm start
```
